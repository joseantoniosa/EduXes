// Referencia á base de datos
var db;

function onDeviceReady() {
	console.log("Hello World\n");
	
	$("#inicio").html("<b>Capa inicial</b>");
 //   db = window.openDatabase("CardsDB", "1.0", "Cards DataBase", 200000);
//    db.transaction(populateDB, errorCB, successCB);

	
//    loadCards();
}

function init(){
	console.log("Hello World 0\n");
//	$("#inicio").html("<b>Capa inicial</b>"); // works!
	
	document.addEventListener("deviceready", onDeviceReady, false);
	console.log("Hello World 1 ");
}
